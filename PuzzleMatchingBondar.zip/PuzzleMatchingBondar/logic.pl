% logic.pl

перехід(0, 7, 3).
перехід(1, null, 2).
перехід(3, 1, 3).
перехід(3, 7, 2).
перехід(4, 1, 2).
перехід(6, 5, 1).
перехід(7, null, 3).
перехід(7, 1, 1).
перехід(8, 0, 1).
перехід(8, 2, 2).
перехід(8, 3, 2).
перехід(8, 4, 3).
перехід(8, 5, 2).
перехід(8, 6, 1).
перехід(8, 9, 1).
перехід(9, 3, 1).
перехід(9, 4, 2).
перехід(9, 5, 1).
перехід(9, 7, 3).
перехід(+, -, 1).

change(Numb, N, Res, X):-
    перехід(Numb, Res, X),
    N+1 > X.

перетворення([], _, []):-!.
перетворення([H|T], Price, [[[]|L]|Changes]):-
    findall([Res,X], change(H, Price, Res, X), L),
    перетворення(T, Price, Changes).

перетворення_обернене([], _, []):-!.
перетворення_обернене([H|T], Price, [[[]|L]|Changes]):-
    findall([Res,X], change(Res, Price, H, X), L),
    перетворення_обернене(T, Price, Changes).


список_в_вираз([0|[_|_]], 0, ['false']):-!.
список_в_вираз([], 0, []):-!.
список_в_вираз([H|T], Count, Res):-
    H == null,
    список_в_вираз(T, Count, Res),!.
список_в_вираз([H|T], 0, [H|Res]):-
    (H=='+';H=='-';H=='='),
    список_в_вираз(T, _, Res),!.
список_в_вираз([H|T], Count, Res):-
    список_в_вираз(T, Count1, R),
    ((Count1 =:= 0, список_в_вираз_0(H,R,Res));(Count1 > 0,список_в_вираз_1(H,R,Count1,Res))),
    Count is Count1 +1,!.
список_в_вираз_0(H,R, [H|R]):-!.
список_в_вираз_1(H, [H1|T1],Count, [ResN|T1]):-
    power10(Count, Powered),
    ResN is H*Powered + H1,!.

power10(1,10):-!.
power10(Power, Res) :-
    Power1 is Power - 1,
    power10(Power1, Res1),
    Res is 10*Res1.


iss_list([_]).
iss_list([_|T]):- iss_list(T).

totobola([],[]).
totobola([H|T],[X|LR]):- iss_list(H), !, member(X,H), totobola(T,LR).
totobola([H|T],[H|LR]):- totobola(T,LR).

clear_price(L, P, R):-
    findall(Res, (totobola(L,Res),sump(Res,N),N=:=P),R),!.

sump([],0):-!.
sump([[]|T],R):-
    sump(T,R),!.
sump([[_|P]|T],R):-
    sump(T,R1),
    R is R1+P.

перетворення_виразу([], [], []).
перетворення_виразу([H|T], [[]|T1], [H|R]):-
    перетворення_виразу(T, T1, R),!.
перетворення_виразу([_|T], [[Ch,_]|T1], [Ch|R]):-
    перетворення_виразу(T, T1, R).

arifm([N1,=,N1]):-!.
arifm([N1|['-'|[N2|T]]]):-
    R is N1-N2,
    arifm([R|T]),!.
arifm([N1|['+'|[N2|T]]]):-
    R is N1+N2,
    arifm([R|T]).

x(L, P, Ch, R):-
    clear_price(Ch, P, F),
    member(X, F),
    перетворення_виразу(L, X, Res),
    список_в_вираз(Res, _, R).

розв(L,P,R):-
    перетворення(L, P, Ch),
    x(L, P, Ch, R),
    append(_,[E],R),
    not(E=='false'),
    append(_,[S1|[S2,_]],R),
    not(((S1 == '+';S1 == '-';S1=='='),(S2 == '+';S2 == '-';S2=='='))),
    arifm(R).
генератор(R,P,G):-
    перетворення_обернене(R, P, Ch2),
    x(R,P, Ch2, G),
    append(_,[E],G),
    not(E=='false').

гра(L,P,Res,Gen):-
    findall(R, розв(L,P,R), Res),
    findall(G, (member(R,Res),генератор(R,P,G)), Gen),!.
